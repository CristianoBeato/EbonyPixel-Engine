/*
===========================================================================

Doom 3 BFG Edition GPL Source Code
Copyright (C) 1993-2012 id Software LLC, a ZeniMax Media company.
Copyright (C) 2016-2018 Cristiano Beato.

This file is part of the Doom 3 BFG Edition GPL Source Code ("Doom 3 BFG Edition Source Code").

Doom 3 BFG Edition Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Doom 3 BFG Edition Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Doom 3 BFG Edition Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Doom 3 BFG Edition Source Code is also subject to certain additional terms. You should have received a copy of these additional terms immediately following the terms and conditions of the GNU General Public License which accompanied the Doom 3 BFG Edition Source Code.  If not, please request a copy in writing from id Software at the address below.

If you have questions concerning this license or the applicable additional terms, you may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville, Maryland 20850 USA.

===========================================================================
*/
#include "precompiled.h"
#pragma hdrstop

#include "sys_thread.h"

/*
=======================================
thread local storage
=======================================
*/
idSysThreadLocalStorage::idSysThreadLocalStorage(void)
{
	tlsIndex = SDL_TLSCreate();
}

idSysThreadLocalStorage::idSysThreadLocalStorage(const ptrdiff_t & val)
{
	SDL_TLSSet(tlsIndex, (const void*)val, destructor);
}

idSysThreadLocalStorage::~idSysThreadLocalStorage(void)
{
}

idSysThreadLocalStorage::operator ptrdiff_t(void)
{
	return (ptrdiff_t)SDL_TLSGet(tlsIndex);
}

const ptrdiff_t & idSysThreadLocalStorage::operator=(const ptrdiff_t & val)
{
	SDL_TLSSet(tlsIndex, (const void*)val, destructor);
	return val;
}

void idSysThreadLocalStorage::destructor(void * ptr)
{
}

/*
=======================================
thread handler functions
=======================================
*/
thrIDHandle_t Sys_GetThreadID(thrHandle_t threadHandle)
{
	if (threadHandle.handle == NULL)
		return 0;

	if (threadHandle.threadId == 0)
		return 0;


	return threadHandle.threadId;
}

/*
=======================================
thread handler functions
=======================================
*/
thrIDHandle_t Sys_GetCurrentThreadID(void)
{
	return SDL_ThreadID();
}

thrHandle_t Sys_CreateThread(xthread_t function, void * parms, xthreadPriority priority, const char * name, core_t core, int stackSize, bool suspended)
{
	int error;
	thrHandle_t info;
	SDL_ThreadPriority thpriority;

	info.name = name;
	info.handle = SDL_CreateThread(function, name, parms);
	info.threadId = SDL_GetThreadID(info.handle);

	if (info.handle == NULL)
	{
		idLib::common->FatalError("ERROR: SDL_CreateThread %s failed: %s\n", name, SDL_GetError());
		return thrHandle_t();
	}
	//  we better sleep enough to do this
	if (priority == THREAD_HIGHEST)
		thpriority = SDL_THREAD_PRIORITY_HIGH;
	else if (priority == THREAD_ABOVE_NORMAL)
		thpriority = SDL_THREAD_PRIORITY_HIGH;
	else if (priority == THREAD_NORMAL)
		thpriority = SDL_THREAD_PRIORITY_NORMAL;
	else if (priority == THREAD_BELOW_NORMAL)
		thpriority = SDL_THREAD_PRIORITY_LOW;
	else if (priority == THREAD_LOWEST)
		thpriority = SDL_THREAD_PRIORITY_LOW;

	if (SDL_SetThreadPriority(thpriority) != 0)
		idLib::common->FatalError("ERROR: SDL_SetThreadPriority %s failed: %s\n", name, SDL_GetError());

	// Under SDL, we don't set the thread affinity and let the OS deal with scheduling
	return info;
}

/*
========================
Sys_DestroyThread
========================
*/
void Sys_DestroyThread(thrHandle_t threadHandle)
{
	if (threadHandle.threadId == 0)
		return;

	char	name[128];
	name[0] = '\0';

	//wayt thread exit
	SDL_WaitThread(threadHandle.handle, NULL);

	threadHandle.name = NULL;
	threadHandle.handle = NULL;
	threadHandle.threadId = 0;
}

//SDL Hack to simulate pthread_Yield
void Sys_Yield(void)
{
#if 0
	SDL_Delay(0);
#else
#if  defined(_WIN32) || defined(_WIN64)
	SwitchToThread();
#elif defined(__ANDROID__) || defined(__APPLE__)
	sched_yield();
#else
	pthread_yield();
#endif
#endif
}