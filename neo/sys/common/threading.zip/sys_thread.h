/*
===========================================================================

Doom 3 BFG Edition GPL Source Code
Copyright (C) 1993-2012 id Software LLC, a ZeniMax Media company.
Copyright (C) 2016-2018 Cristiano Beato.

This file is part of the Doom 3 BFG Edition GPL Source Code ("Doom 3 BFG Edition Source Code").

Doom 3 BFG Edition Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Doom 3 BFG Edition Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Doom 3 BFG Edition Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Doom 3 BFG Edition Source Code is also subject to certain additional terms. You should have received a copy of these additional terms immediately following the terms and conditions of the GNU General Public License which accompanied the Doom 3 BFG Edition Source Code.  If not, please request a copy in writing from id Software at the address below.

If you have questions concerning this license or the applicable additional terms, you may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville, Maryland 20850 USA.

===========================================================================
*/

#ifndef _SYS_THREAD_H_
#define _SYS_THREAD_H_

#include <SDL_thread.h>

#ifndef __TYPEINFOGEN__
/*
================================================================================================
Platform portable mutex, signal, atomic integer and memory barrier.
================================================================================================
*/

typedef SDL_threadID			thrIDHandle_t;
typedef SDL_ThreadFunction		xthread_t;

//thread handler
typedef struct
{
	const char			*name;
	SDL_Thread			*handle;
	thrIDHandle_t		threadId;
}thrHandle_t;

#endif

/*
================================================================================================
Platform specific thread local storage.
Can be used to store either a pointer or an integer.
================================================================================================
*/

class idSysThreadLocalStorage
{
public:
	idSysThreadLocalStorage(void);
	idSysThreadLocalStorage(const ptrdiff_t& val);
	~idSysThreadLocalStorage(void);

	operator ptrdiff_t(void);
	const ptrdiff_t& operator = (const ptrdiff_t& val);

private:
	static void destructor(void * ptr);
	SDL_TLSID	tlsIndex;
};

#define ID_TLS idSysThreadLocalStorage

/*
================================================================================================
Platform independent threading functions.
================================================================================================
*/
#define DEFAULT_THREAD_STACK_SIZE		( 256 * 1024 )

enum core_t
{
	CORE_ANY = -1,
	CORE_0A,
	CORE_0B,
	CORE_1A,
	CORE_1B,
	CORE_2A,
	CORE_2B
};

enum xthreadPriority
{
	THREAD_LOWEST,
	THREAD_BELOW_NORMAL,
	THREAD_NORMAL,
	THREAD_ABOVE_NORMAL,
	THREAD_HIGHEST
};

// RB begin
// removed unused Sys_WaitForThread
// RB end

thrIDHandle_t		Sys_GetThreadID(thrHandle_t threadHandle);

// on SDL_thread, the threadID is NOT the same as the threadHandle
thrIDHandle_t		Sys_GetCurrentThreadID(void);

// returns a threadHandle
thrHandle_t			Sys_CreateThread(xthread_t function, void* parms, xthreadPriority priority,
	const char* name, core_t core, int stackSize = DEFAULT_THREAD_STACK_SIZE,
	bool suspended = false);

void				Sys_DestroyThread(thrHandle_t threadHandle);
void				Sys_Yield(void);
#endif // !_SYS_THREAD_H_
