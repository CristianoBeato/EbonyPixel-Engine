/*
===========================================================================

Doom 3 BFG Edition GPL Source Code
Copyright (C) 1993-2012 id Software LLC, a ZeniMax Media company.
Copyright (C) 2016-2018 Cristiano Beato.

This file is part of the Doom 3 BFG Edition GPL Source Code ("Doom 3 BFG Edition Source Code").

Doom 3 BFG Edition Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Doom 3 BFG Edition Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Doom 3 BFG Edition Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Doom 3 BFG Edition Source Code is also subject to certain additional terms. You should have received a copy of these additional terms immediately following the terms and conditions of the GNU General Public License which accompanied the Doom 3 BFG Edition Source Code.  If not, please request a copy in writing from id Software at the address below.

If you have questions concerning this license or the applicable additional terms, you may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville, Maryland 20850 USA.

===========================================================================
*/
#include "precompiled.h"
#pragma hdrstop

#include "sys_InterlockedInteger.h"
/*
================================================================================================

Interlocked Integer

================================================================================================
*/

interlockedInt_t	Sys_GetInterlockedVal(interlocked_t value)
{
	return SDL_AtomicGet(&value);
}

interlockedInt_t Sys_SetInterlockedVal(interlocked_t & value, interlockedInt_t newVar)
{
	return SDL_AtomicSet(&value, newVar);
}

/*
========================
Sys_InterlockedIncrement
========================
*/
interlockedInt_t Sys_InterlockedIncrement(interlockedInt_t& value)
{
	//return __sync_add_and_fetch(&value, 1);
	interlocked_t intlk;
	SDL_AtomicSet(&intlk, value);
	SDL_AtomicAdd(&intlk, 1);
	value = SDL_AtomicGet(&intlk);
	return value;
}

/*
========================
Sys_InterlockedDecrement
========================
*/
interlockedInt_t Sys_InterlockedDecrement(interlockedInt_t& value)
{
	//return __sync_sub_and_fetch(&value, 1);
	interlocked_t intlk;
	SDL_AtomicSet(&intlk, value);
	SDL_AtomicAdd(&intlk, -1);
	value = SDL_AtomicGet(&intlk);
	return value;
}

/*
========================
Sys_InterlockedAdd
========================
*/
interlockedInt_t Sys_InterlockedAdd(interlockedInt_t& value, interlockedInt_t i)
{
	//return __sync_add_and_fetch(&value, i);
	interlocked_t intlk;
	SDL_AtomicSet(&intlk, value);
	SDL_AtomicAdd(&intlk, i);
	value = SDL_AtomicGet(&intlk);
	return value;
}

/*
========================
Sys_InterlockedSub
========================
*/
interlockedInt_t Sys_InterlockedSub(interlockedInt_t& value, interlockedInt_t i)
{
	//return __sync_sub_and_fetch(&value, i);
	interlocked_t intlk;
	SDL_AtomicSet(&intlk, value);
	SDL_AtomicAdd(&intlk, -i);
	value = SDL_AtomicGet(&intlk);
	return value;
}

/*
========================
Sys_InterlockedExchange
========================
*/
interlockedInt_t Sys_InterlockedExchange(interlockedInt_t& value, interlockedInt_t exchange)
{
	interlocked_t intlk;
	// source: http://gcc.gnu.org/onlinedocs/gcc-4.1.1/gcc/Atomic-Builtins.html
	// These builtins perform an atomic compare and swap. That is, if the current value of *ptr is oldval, then write newval into *ptr.
	//return __sync_val_compare_and_swap(&value, value, exchange);
	SDL_AtomicSet(&intlk, value);
	SDL_AtomicCAS(&intlk, value, exchange);
	value = SDL_AtomicGet(&intlk);
	return value;
}

/*
========================
Sys_InterlockedCompareExchange
========================
*/
interlockedInt_t Sys_InterlockedCompareExchange(interlockedInt_t& value, interlockedInt_t comparand, interlockedInt_t exchange)
{
	interlocked_t intlk;
	//return __sync_val_compare_and_swap(&value, comparand, exchange);
	SDL_AtomicSet(&intlk, value);
	SDL_AtomicCAS(&intlk, comparand, exchange);
	value = SDL_AtomicGet(&intlk);
	return value;
}

/*
================================================================================================
Interlocked Pointer
================================================================================================
*/

/*
========================
Sys_InterlockedExchangePointer
========================
*/
void* Sys_InterlockedExchangePointer(void*& ptr, void* exchange)
{
	//return __sync_val_compare_and_swap(&ptr, ptr, exchange);
	SDL_AtomicCASPtr(&ptr, ptr, exchange);
	return ptr;
}

/*
========================
Sys_InterlockedCompareExchangePointer
========================
*/
void* Sys_InterlockedCompareExchangePointer(void*& ptr, void* comparand, void* exchange)
{
	//return __sync_val_compare_and_swap(&ptr, comparand, exchange);
	SDL_AtomicCASPtr(&ptr, comparand, exchange);
	return ptr;
}
