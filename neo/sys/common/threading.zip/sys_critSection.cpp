/*
===========================================================================

Doom 3 BFG Edition GPL Source Code
Copyright (C) 1993-2012 id Software LLC, a ZeniMax Media company.
Copyright (C) 2016-2018 Cristiano Beato.

This file is part of the Doom 3 BFG Edition GPL Source Code ("Doom 3 BFG Edition Source Code").

Doom 3 BFG Edition Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Doom 3 BFG Edition Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Doom 3 BFG Edition Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Doom 3 BFG Edition Source Code is also subject to certain additional terms. You should have received a copy of these additional terms immediately following the terms and conditions of the GNU General Public License which accompanied the Doom 3 BFG Edition Source Code.  If not, please request a copy in writing from id Software at the address below.

If you have questions concerning this license or the applicable additional terms, you may contact in writing id Software LLC, c/o ZeniMax Media Inc., Suite 120, Rockville, Maryland 20850 USA.

===========================================================================
*/
#include "precompiled.h"
#pragma hdrstop

#include "sys_critSection.h"


/*
================================================================================================

Signal

================================================================================================
*/

/*
========================
Sys_SignalCreate
========================
*/
void Sys_SignalCreate(signalHandle_t& handle, bool manualReset)
{
	handle.manualReset = manualReset;
	// if this is true, the signal is only set to nonsignaled when Clear() is called,
	// else it's "auto-reset" and the state is set to !signaled after a single waiting
	// thread has been released

	// the inital state is always "not signaled"
	handle.signaled = false;
	handle.waiting = 0;

	handle.mutex = SDL_CreateMutex();
	handle.cond = SDL_CreateCond();
}

/*
========================
Sys_SignalDestroy
========================
*/
void Sys_SignalDestroy(signalHandle_t& handle)
{
	// CloseHandle( handle );
	handle.signaled = false;
	handle.waiting = 0;
	SDL_DestroyCond(handle.cond);
	SDL_DestroyMutex(handle.mutex);
}

/*
========================
Sys_SignalRaise
========================
*/
void Sys_SignalRaise(signalHandle_t& handle)
{
	SDL_LockMutex(handle.mutex);

	if (handle.manualReset)
	{
		// signaled until reset
		handle.signaled = true;
		// wake *all* threads waiting on this cond
		SDL_CondBroadcast(handle.cond);
	}
	else
	{
		// automode: signaled until first thread is released
		if (handle.waiting > 0)
			SDL_CondBroadcast(handle.cond); // there are waiting threads => release one
		else
		{
			// no waiting threads, save signal
			handle.signaled = true;
			// while the MSDN documentation is a bit unspecific about what happens
			// when SetEvent() is called n times without a wait inbetween
			// (will only one wait be successful afterwards or n waits?)
			// it seems like the signaled state is a flag, not a counter.
			// http://stackoverflow.com/a/13703585 claims the same.
		}
	}

	SDL_LockMutex(handle.mutex);
}

/*
========================
Sys_SignalClear
========================
*/
void Sys_SignalClear(signalHandle_t& handle)
{
	SDL_LockMutex(handle.mutex);

	// TODO: probably signaled could be atomically changed?
	handle.signaled = false;

	SDL_LockMutex(handle.mutex);
}


/*
========================
Sys_SignalWait
========================
*/
bool Sys_SignalWait(signalHandle_t& handle, int timeout)
{
	//DWORD result = WaitForSingleObject( handle, timeout == idSysSignal::WAIT_INFINITE ? INFINITE : timeout );
	//assert( result == WAIT_OBJECT_0 || ( timeout != idSysSignal::WAIT_INFINITE && result == WAIT_TIMEOUT ) );
	//return ( result == WAIT_OBJECT_0 );

	int status;
	SDL_LockMutex(handle.mutex);

	if (handle.signaled) // there is a signal that hasn't been used yet
	{
		if (!handle.manualReset) // for auto-mode only one thread may be released - this one.
			handle.signaled = false;

		status = 0; // success!
	}
	else // we'll have to wait for a signal
	{
		++handle.waiting;
		if (timeout == idSysSignal::WAIT_INFINITE)
			status = SDL_CondWait(handle.cond, handle.mutex);
		else
			status = SDL_CondWaitTimeout(handle.cond, handle.mutex, timeout);

		--handle.waiting;
	}

	SDL_LockMutex(handle.mutex);

	assert(status == 0 || (timeout != idSysSignal::WAIT_INFINITE && status == ETIMEDOUT));

	return (status == 0);

}

/*
================================================================================================

Mutex

================================================================================================
*/

/*
========================
Sys_MutexCreate
========================
*/
void Sys_MutexCreate(mutexHandle_t& handle)
{
	handle = SDL_CreateMutex();
}

/*
========================
Sys_MutexDestroy
========================
*/
void Sys_MutexDestroy(mutexHandle_t& handle)
{
	assert(handle == nullptr);
	SDL_DestroyMutex(handle);
}

/*
========================
Sys_MutexLock
========================
*/
bool Sys_MutexLock(mutexHandle_t& handle, bool blocking)
{
	assert(handle == nullptr);
	if (SDL_TryLockMutex(handle) != 0)
	{
		if (!blocking)
			return false;

		SDL_LockMutex(handle);
	}
	return true;
}

/*
========================
Sys_MutexUnlock
========================
*/
void Sys_MutexUnlock(mutexHandle_t& handle)
{
	assert(handle == nullptr);
	SDL_UnlockMutex(handle);
}