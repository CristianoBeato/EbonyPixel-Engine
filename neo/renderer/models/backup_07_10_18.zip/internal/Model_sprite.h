/*
===========================================================================

Elbony Pixel Source Code
Copyright (C) 2017-2018 Cristiano Beato

This file is part of the Elbony Pixel Source Code ("Elbony Pixel Source Code").

Elbony Pixel Source Code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Elbony Pixel Source Code is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Elbony Pixel Source Code.  If not, see <http://www.gnu.org/licenses/>.

In addition, the Elbony Pixel Source Code is also subject to certain additional terms.
You should have received a copy of these additional terms immediately following the terms and conditions of the
GNU General Public License which accompanied the Elbony Pixel Source Code.

===========================================================================
*/

#ifndef __SPRITE_MODEL_H__
#define __SPRITE_MODEL_H__

/*
================================================================================

idRenderModelSprite

================================================================================
*/

class idRenderModelSprite : public idRenderModelStatic
{
public:
	virtual	dynamicModel_t		IsDynamicModel() const;
	virtual bool				SupportsBinaryModel()
	{
		return false;
	}
	virtual	bool				IsLoaded() const;
	virtual	idRenderModel* 		InstantiateDynamicModel(const struct renderEntity_s* ent, const viewDef_t* view, idRenderModel* cachedModel);
	virtual	idBounds			Bounds(const struct renderEntity_s* ent) const;

	// with the addModels2 arrangement we could have light accepting and
	// shadowing dynamic models, but the original game never did
	virtual bool				ModelHasDrawingSurfaces() const
	{
		return true;
	};
	virtual bool				ModelHasInteractingSurfaces() const
	{
		return false;
	};
	virtual bool				ModelHasShadowCastingSurfaces() const
	{
		return false;
	};
};

#endif /* !__SPRITE_MODEL_H__ */
